
This folder has been created by MonitoraPA on 2022-08-28.
https://monitora-pa.it/

Everything inside this folder can be used according to the terms 
and conditions of the Hacking License.

Read LICENCE.txt for the exact terms and conditions applied.
